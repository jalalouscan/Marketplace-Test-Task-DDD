export class ProductImage {
  constructor(
    public readonly id: string,
    public readonly url: string,
  ) {}
}
